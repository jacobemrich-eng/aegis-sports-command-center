# GameTwin v2.0 Asset Origin Note

The bundled character/stadium GLBs remain the original GameTwin-generated v1.7 assets produced by `scripts/generate-generic-assets.py`. v2.0 adds no copied commercial-game assets, official team logos, exact player likeness meshes, motion-captured MLB player performances, or licensed exact MLB stadium meshes.

v2.0 changes broadcast graphics and event presentation only. Asset provenance remains v1.7.
