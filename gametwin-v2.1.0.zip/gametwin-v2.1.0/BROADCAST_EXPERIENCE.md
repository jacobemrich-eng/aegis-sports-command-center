# GameTwin v2.0 Broadcast Experience Contract

## Persistent graphics
- Compact scorebug: inning / outs / count / score / bases.
- Pitcher-batter matchup strip.
- GameTwin pregame probability chip.
- Shadow-mode / 0% AEGIS weight badge.

## Contextual graphics
- Pitch-location box: plate x/z, pitch name, velocity, visual zone relation.
- Contact card: EV, LA, projected representative distance.
- Lower-third: at-bat, result, baserunning, inning state, bullpen.
- Replay ribbon: pass name and replay speed.
- Full-frame break card: inning, automatic runner, pitching change.
- `SIM STATE EST.`: bounded representative game-state estimate only.

## Integrity rules
- The pitch-location dot cannot alter ball/strike or PA outcome.
- Contact telemetry cannot alter batted-ball result.
- Replay graphics cannot alter the event or rerun the prediction model.
- `SIM STATE EST.` is never described as calibrated live WP and is never written into AEGIS/model calibration fields.
- Broadcast overlays must fail open: hiding the overlay is preferred to interrupting the simulation.
