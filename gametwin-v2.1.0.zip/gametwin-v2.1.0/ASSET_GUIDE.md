# GameTwin v2.0 Asset Guide

v2.0 does not regenerate or relabel the original v1.7 GLB assets. It adds the TV presentation layer around them.

The v1.9 virtual director camera set remains active: `broadcast`, `batter`, `pitcher`, `ball_track`, `stadium`, `plate_low`, `outfield_wall`, `dugout`, `cf`, and base cameras. Future original/licensed assets should preserve clean negative space for lower-thirds, the pitch-location overlay, scorebug, replay ribbon, and full-frame inning/bullpen transition graphics.

Continue using the existing mobile LOD/triangle budgets. No asset may become required for simulation correctness.
