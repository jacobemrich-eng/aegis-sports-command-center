# GameTwin v2.1.0 Production Shadow Pilot Runbook

1. Keep production AEGIS main unchanged; work on a feature branch.
2. Run `npm run check` in the v2.1 package.
3. Run `node scripts/verify-deployment-readiness.js` and require `ok=true`.
4. Run `node scripts/install-into-aegis-v8.9.3.js --preflight <AEGIS_REPO>` and require `compatible=true` with `write_performed=false`.
5. Install only after preflight passes.
6. Open WATCH on a WebGL2-capable phone in compact portrait, standard portrait, and landscape.
7. Force simultaneous contextual overlays and confirm scorebug/matchup remain readable and replay/break-card priority suppresses lower-priority HUD pieces.
8. Test short landscape (height <= 520px) and verify nonessential badges/state graphics collapse.
9. Enable OS Reduced Motion and confirm presentation transitions collapse without changing sim timing/outcomes.
10. Collect runtime `gametwin:performance-sample` events; inspect FPS/p95/long-frame rate on Low/Medium/High. A RED sample may recommend a lower tier but must not change quality automatically.
11. Trigger WebGL context loss/fallback and confirm GameTwin/Aegis remain usable.
12. Confirm all 27 bundled GLB URLs resolve locally and asset-status failures fall back to procedural visuals.
13. Verify `SIM STATE EST.` still says `NOT LIVE WP` and does not enter calibration/model fields.
14. Confirm `aegis_weight=0`, `release_eligible=false`, no release/unit/parlay authority.
15. Verify AEGIS Final Card, Game Lab, Results, Models, Supabase persistence, Render behavior, and autopilot before merge/deploy.
