# GameTwin v2.1.0

## Broadcast Refinement & Deployment Readiness
- Added `public/gametwin-readiness.mjs` v2.1.0.
- Added explicit viewport/orientation profiles including compact portrait and short landscape.
- Added collision-safe overlay planning and mobile HUD suppression/placement rules.
- Added safe-area layout refinements and reduced-motion support.
- Added advisory frame-performance telemetry: FPS, average/p95 frame time, long-frame rate, health grade, and quality recommendation without automatic quality mutation.
- Added WebGL context loss/restoration telemetry.
- Added asset-readiness summaries to the renderer asset-status event.
- Added package deployment verifier for local assets, cache versions, required files, and shadow firewall checks.
- Added read-only installer `--preflight` for AEGIS v8.9.3 compatibility checks.
- Preserved v2.0 broadcast experience, v1.9 director, v1.8 choreography, v1.7 assets/animations, and the frozen predictive/calibration stack.
