# AEGIS MLB GameTwin v2.1.0 — Broadcast Refinement & Deployment Readiness

GameTwin v2.1 freezes the v2.0 Broadcast Experience, v1.9 director/replay engine, v1.8 choreography, v1.7 animation/assets, and the 25,000-simulation predictive path. This release concentrates on mobile reliability, HUD collision prevention, renderer observability, asset verification, and a safer AEGIS deployment handoff.

## What v2.1 adds
- Viewport profiles: compact portrait, mobile portrait, short landscape, mobile landscape, tablet, and desktop.
- Collision-safe HUD policy for pitch location, contact telemetry, lower thirds, `SIM STATE EST.`, replay ribbon, transition cards, and controls.
- Short-landscape and safe-area CSS for modern iPhone/Android screen cutouts.
- `prefers-reduced-motion` presentation fallback.
- Advisory WebGL frame monitor with FPS, p95 frame time, long-frame rate, GREEN/YELLOW/RED grade, and recommended quality tier. It never changes graphics quality automatically.
- WebGL context lost/restored telemetry.
- Asset-readiness summaries for configured/loaded/failure/warning state.
- `scripts/verify-deployment-readiness.js` for package-local deployment checks.
- Read-only `--preflight` mode in the AEGIS v8.9.3 guarded installer.

## Provenance
- Character/stadium GLBs and advanced baseball animation: v1.7.
- Cinematic choreography: v1.8.
- Broadcast Director / multi-pass replay: v1.9.
- Broadcast Experience / TV graphics: v2.0.
- Broadcast refinement / deployment readiness: **v2.1**.

## Integrity
Renderer performance, viewport layout, asset load status, WebGL health, and overlay placement are presentation telemetry only. They cannot alter any plate-appearance outcome, GameTwin probability, calibration record, AEGIS model output, Final Card, unit size, or parlay.

## Governance
`aegis_weight=0`, `release_eligible=false`, automatic weight changes disabled, and no Core/Secondary/unit/parlay authority.
