#!/usr/bin/env python3
import json, math, struct, argparse, hashlib
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'public'/'gametwin-assets'

CT_FLOAT=5126; CT_USHORT=5123; CT_UINT=5125
TYPE_COMPONENTS={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}


def align4(n): return (n+3)&~3

def quat_xyz(rx=0,ry=0,rz=0):
    cx,cy,cz=math.cos(rx/2),math.cos(ry/2),math.cos(rz/2)
    sx,sy,sz=math.sin(rx/2),math.sin(ry/2),math.sin(rz/2)
    # XYZ intrinsic / Three Euler default-compatible composition
    return np.array([
        sx*cy*cz + cx*sy*sz,
        cx*sy*cz - sx*cy*sz,
        cx*cy*sz + sx*sy*cz,
        cx*cy*cz - sx*sy*sz,
    ],dtype=np.float32)

class GLB:
    def __init__(self):
        self.j={'asset':{'version':'2.0','generator':'AEGIS GameTwin Original Asset Generator v1.5'},'scene':0,'scenes':[{'nodes':[]}],
                'nodes':[],'meshes':[],'materials':[],'bufferViews':[],'accessors':[],'buffers':[{'byteLength':0}], 'animations':[]}
        self.bin=bytearray()
    def add_bytes(self,b,target=None):
        off=align4(len(self.bin));
        if off>len(self.bin): self.bin.extend(b'\x00'*(off-len(self.bin)))
        self.bin.extend(b); idx=len(self.j['bufferViews']); view={'buffer':0,'byteOffset':off,'byteLength':len(b)}
        if target: view['target']=target
        self.j['bufferViews'].append(view); return idx
    def add_accessor(self,arr,componentType,typ,target=None,minmax=False,normalized=False):
        arr=np.asarray(arr)
        if componentType==CT_FLOAT: arr=arr.astype('<f4',copy=False)
        elif componentType==CT_USHORT: arr=arr.astype('<u2',copy=False)
        elif componentType==CT_UINT: arr=arr.astype('<u4',copy=False)
        else: raise ValueError(componentType)
        bv=self.add_bytes(arr.tobytes(),target)
        count=arr.size//TYPE_COMPONENTS[typ]
        a={'bufferView':bv,'byteOffset':0,'componentType':componentType,'count':count,'type':typ}
        if normalized:a['normalized']=True
        if minmax:
            resh=arr.reshape(count,TYPE_COMPONENTS[typ]);a['min']=resh.min(axis=0).astype(float).tolist();a['max']=resh.max(axis=0).astype(float).tolist()
        idx=len(self.j['accessors']);self.j['accessors'].append(a);return idx
    def add_material(self,name,color,rough=.6,metal=.02,emissive=None):
        pbr={'baseColorFactor':[float(color[0]),float(color[1]),float(color[2]),float(color[3])],'metallicFactor':metal,'roughnessFactor':rough}
        m={'name':name,'pbrMetallicRoughness':pbr,'doubleSided':False}
        if emissive:m['emissiveFactor']=list(emissive)
        idx=len(self.j['materials']);self.j['materials'].append(m);return idx
    def add_mesh_primitive(self,name,pos,norm,idxs,joints,weights,mat):
        attrs={'POSITION':self.add_accessor(pos,CT_FLOAT,'VEC3',34962,True),'NORMAL':self.add_accessor(norm,CT_FLOAT,'VEC3',34962),
               'JOINTS_0':self.add_accessor(joints,CT_USHORT,'VEC4',34962),'WEIGHTS_0':self.add_accessor(weights,CT_FLOAT,'VEC4',34962)}
        ind=self.add_accessor(idxs,CT_UINT,'SCALAR',34963)
        mesh={'name':name,'primitives':[{'attributes':attrs,'indices':ind,'material':mat}]};mi=len(self.j['meshes']);self.j['meshes'].append(mesh);return mi
    def add_static_mesh(self,name,pos,norm,idxs,mat):
        attrs={'POSITION':self.add_accessor(pos,CT_FLOAT,'VEC3',34962,True),'NORMAL':self.add_accessor(norm,CT_FLOAT,'VEC3',34962)}
        ind=self.add_accessor(idxs,CT_UINT,'SCALAR',34963);mi=len(self.j['meshes']);self.j['meshes'].append({'name':name,'primitives':[{'attributes':attrs,'indices':ind,'material':mat}]});return mi
    def add_node(self,name,**kwargs):
        n={'name':name};n.update(kwargs);idx=len(self.j['nodes']);self.j['nodes'].append(n);return idx
    def add_animation(self,name,tracks):
        # tracks: [{node,path,times,values,type}]
        anim={'name':name,'samplers':[],'channels':[]}
        time_cache={}
        for tr in tracks:
            key=tuple(float(x) for x in tr['times'])
            if key not in time_cache: time_cache[key]=self.add_accessor(np.array(key,dtype=np.float32),CT_FLOAT,'SCALAR',None,True)
            inp=time_cache[key]; out=self.add_accessor(np.array(tr['values'],dtype=np.float32),CT_FLOAT,tr['type'])
            si=len(anim['samplers']);anim['samplers'].append({'input':inp,'output':out,'interpolation':tr.get('interpolation','LINEAR')})
            anim['channels'].append({'sampler':si,'target':{'node':tr['node'],'path':tr['path']}})
        self.j['animations'].append(anim)
    def write(self,path):
        self.j['buffers'][0]['byteLength']=len(self.bin)
        js=json.dumps(self.j,separators=(',',':')).encode('utf-8'); js+=b' '*(align4(len(js))-len(js))
        bb=bytes(self.bin);bb+=b'\x00'*(align4(len(bb))-len(bb))
        total=12+8+len(js)+8+len(bb)
        out=struct.pack('<4sII',b'glTF',2,total)+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(bb),b'BIN\x00')+bb
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(out)
        return hashlib.sha256(out).hexdigest()


def normalize(v):
    v=np.asarray(v,float);n=np.linalg.norm(v);return v/n if n>1e-9 else v

def orthobasis(axis):
    a=normalize(axis);t=np.array([1.,0.,0.]) if abs(a[0])<.8 else np.array([0.,0.,1.]);u=normalize(np.cross(a,t));v=np.cross(a,u);return a,u,v

def cylinder_between(a,b,r=0.2,segments=10,caps=True):
    a=np.array(a,float);b=np.array(b,float);axis,u,v=orthobasis(b-a);verts=[];norms=[]
    for p in [a,b]:
        for i in range(segments):
            th=2*math.pi*i/segments;rad=math.cos(th)*u+math.sin(th)*v;verts.append(p+rad*r);norms.append(rad)
    inds=[]
    for i in range(segments):
        j=(i+1)%segments;inds += [i,j,segments+j, i,segments+j,segments+i]
    if caps:
        ca=len(verts);verts.append(a);norms.append(-axis);cb=len(verts);verts.append(b);norms.append(axis)
        for i in range(segments):
            j=(i+1)%segments;inds += [ca,j,i, cb,segments+i,segments+j]
    return np.array(verts,np.float32),np.array(norms,np.float32),np.array(inds,np.uint32)

def uv_sphere(center,r,seg=12,rings=8,scale=(1,1,1)):
    c=np.array(center,float);verts=[];norm=[];inds=[];sx,sy,sz=scale
    for j in range(rings+1):
        ph=math.pi*j/rings
        for i in range(seg+1):
            th=2*math.pi*i/seg;x=math.sin(ph)*math.cos(th);y=math.cos(ph);z=math.sin(ph)*math.sin(th)
            p=c+np.array([x*r*sx,y*r*sy,z*r*sz]);verts.append(p);nn=normalize([x/sx,y/sy,z/sz]);norm.append(nn)
    for j in range(rings):
        for i in range(seg):
            a=j*(seg+1)+i;b=a+1;d=(j+1)*(seg+1)+i;c2=d+1;inds += [a,d,b,b,d,c2]
    return np.array(verts,np.float32),np.array(norm,np.float32),np.array(inds,np.uint32)

def box(center,size):
    cx,cy,cz=center;sx,sy,sz=[x/2 for x in size]
    faces=[((0,0,1),[(-sx,-sy,sz),(sx,-sy,sz),(sx,sy,sz),(-sx,sy,sz)]),((0,0,-1),[(sx,-sy,-sz),(-sx,-sy,-sz),(-sx,sy,-sz),(sx,sy,-sz)]),
           ((1,0,0),[(sx,-sy,sz),(sx,-sy,-sz),(sx,sy,-sz),(sx,sy,sz)]),((-1,0,0),[(-sx,-sy,-sz),(-sx,-sy,sz),(-sx,sy,sz),(-sx,sy,-sz)]),
           ((0,1,0),[(-sx,sy,sz),(sx,sy,sz),(sx,sy,-sz),(-sx,sy,-sz)]),((0,-1,0),[(-sx,-sy,-sz),(sx,-sy,-sz),(sx,-sy,sz),(-sx,-sy,sz)])]
    verts=[];norm=[];inds=[]
    for f,(n,ps) in enumerate(faces):
        base=len(verts);verts.extend([(cx+x,cy+y,cz+z) for x,y,z in ps]);norm.extend([n]*4);inds += [base,base+1,base+2,base,base+2,base+3]
    return np.array(verts,np.float32),np.array(norm,np.float32),np.array(inds,np.uint32)

def combine(parts):
    vs=[];ns=[];ii=[];off=0
    for v,n,i in parts:vs.append(v);ns.append(n);ii.append(i+off);off+=len(v)
    return np.concatenate(vs),np.concatenate(ns),np.concatenate(ii)

# Bone hierarchy/local translation
BONES=[
 ('Root',None,(0,0,0)),('Hips','Root',(0,3.15,0)),('Spine','Hips',(0,.82,0)),('Chest','Spine',(0,1.0,0)),('Neck','Chest',(0,1.05,0)),('Head','Neck',(0,.52,0)),
 ('LShoulder','Chest',(-.72,.66,0)),('LElbow','LShoulder',(-.72,-.82,0)),('LWrist','LElbow',(-.62,-.82,0)),
 ('RShoulder','Chest',(.72,.66,0)),('RElbow','RShoulder',(.72,-.82,0)),('RWrist','RElbow',(.62,-.82,0)),
 ('LHip','Hips',(-.42,-.16,0)),('LKnee','LHip',(0,-1.42,0)),('LAnkle','LKnee',(0,-1.3,.03)),
 ('RHip','Hips',(.42,-.16,0)),('RKnee','RHip',(0,-1.42,0)),('RAnkle','RKnee',(0,-1.3,.03)),
]

def bone_worlds():
    d={};parent={n:p for n,p,_ in BONES};local={n:np.array(t,float) for n,_,t in BONES}
    def w(n):
        if n in d:return d[n]
        p=parent[n];d[n]=local[n] if p is None else w(p)+local[n];return d[n]
    for n,_,_ in BONES:w(n)
    return d
BW=bone_worlds()

def inv_bind_translation(pos):
    x,y,z=pos
    # column-major 4x4
    return [1,0,0,0, 0,1,0,0, 0,0,1,0, -x,-y,-z,1]

def weighted_attrs(count,joint_slot):
    j=np.zeros((count,4),dtype=np.uint16);j[:,0]=joint_slot;w=np.zeros((count,4),dtype=np.float32);w[:,0]=1.;return j,w

def make_character(role,lod,out):
    g=GLB();qual={'low':(8,6),'medium':(12,8),'high':(18,12)}[lod];seg,rings=qual
    mats={
      'jersey':g.add_material('GT_Jersey_Primary',(0.08,.42,.88,1),.52,.02),
      'trim':g.add_material('GT_Jersey_Secondary',(.92,.95,.98,1),.48,.01),
      'pants':g.add_material('GT_Pants',(.78,.82,.86,1),.68,.01),
      'skin':g.add_material('GT_Skin',(.64,.38,.24,1),.74,0),
      'gear':g.add_material('GT_Gear',(.025,.04,.06,1),.28,.16),
      'metal':g.add_material('GT_Metal',(.55,.62,.68,1),.26,.72),
      'leather':g.add_material('GT_Leather',(.28,.12,.055,1),.62,.02),
      'shoe':g.add_material('GT_Shoes',(.015,.018,.022,1),.45,.08),
      'bat':g.add_material('GT_Bat',(.55,.30,.12,1),.36,.03),
    }
    # nodes: root scene, bones, skinned mesh node
    root=g.add_node('CharacterRoot');g.j['scenes'][0]['nodes'].append(root)
    bone_nodes={}
    for name,parent,t in BONES:
        node=g.add_node(name,translation=list(map(float,t)));bone_nodes[name]=node
        if parent is None:g.j['nodes'][root].setdefault('children',[]).append(node)
        else:g.j['nodes'][bone_nodes[parent]].setdefault('children',[]).append(node)
    skin_joints=[bone_nodes[n] for n,_,_ in BONES]
    ib=np.array([inv_bind_translation(BW[n]) for n,_,_ in BONES],dtype=np.float32)
    ibacc=g.add_accessor(ib,CT_FLOAT,'MAT4')
    g.j['skins']=[{'name':'GT_BaseballSkeleton','joints':skin_joints,'skeleton':bone_nodes['Root'],'inverseBindMatrices':ibacc}]
    slot={n:i for i,(n,_,_) in enumerate(BONES)}
    primitives=[]
    def addpart(name,geo,joint,mat):
        v,n,i=geo;j,w=weighted_attrs(len(v),slot[joint]);attrs={'POSITION':g.add_accessor(v,CT_FLOAT,'VEC3',34962,True),'NORMAL':g.add_accessor(n,CT_FLOAT,'VEC3',34962),'JOINTS_0':g.add_accessor(j,CT_USHORT,'VEC4',34962),'WEIGHTS_0':g.add_accessor(w,CT_FLOAT,'VEC4',34962)};ind=g.add_accessor(i,CT_UINT,'SCALAR',34963);primitives.append({'attributes':attrs,'indices':ind,'material':mats[mat],'extras':{'part':name,'joint':joint}})
    # torso split for better rotation
    addpart('LowerTorso',box((0,4.18,0),(1.55,1.15,.86)),'Spine','jersey')
    addpart('UpperTorso',box((0,5.05,0),(1.9,1.1,.9)),'Chest','jersey')
    addpart('Head',uv_sphere(BW['Head']+[0,.22,0],.46,seg,rings,scale=(.9,1.08,.94)),'Head','skin')
    # arms
    for side in ['L','R']:
        sh=side+'Shoulder';el=side+'Elbow';wr=side+'Wrist'
        addpart(side+'UpperArm',cylinder_between(BW[sh],BW[el],.23,seg),'%s'%sh,'jersey')
        addpart(side+'Forearm',cylinder_between(BW[el],BW[wr],.19,seg),'%s'%el,'skin')
        addpart(side+'Hand',uv_sphere(BW[wr]+np.array([0,-.12,0]),.22,seg,max(5,rings-2),scale=(.85,1,.75)),wr,'skin')
    # legs
    for side in ['L','R']:
        hp=side+'Hip';kn=side+'Knee';an=side+'Ankle'
        addpart(side+'Thigh',cylinder_between(BW[hp],BW[kn],.31,seg),hp,'pants')
        addpart(side+'Shin',cylinder_between(BW[kn],BW[an],.25,seg),kn,'pants')
        addpart(side+'Shoe',box(BW[an]+np.array([0,-.14,.22]),(.56,.3,.92)),an,'shoe')
    # belt / socks / jersey trim
    addpart('Belt',box((0,3.68,0),(1.62,.14,.91)),'Spine','gear')
    addpart('JerseyTrim',box((0,4.74,.47),(1.65,.08,.05)),'Chest','trim')
    # helmet/cap & role gear
    helmet_roles={'batter','runner','catcher'}
    if role in helmet_roles:
        addpart('Helmet',uv_sphere(BW['Head']+[0,.38,0],.50,seg,rings,scale=(.96,.76,1.0)),'Head','gear')
        addpart('HelmetBrim',box(BW['Head']+np.array([0,.38,.43]),(.78,.08,.42)),'Head','gear')
    elif role!='umpire':
        addpart('Cap',uv_sphere(BW['Head']+[0,.42,0],.49,seg,rings,scale=(.96,.52,1.0)),'Head','gear')
        addpart('CapBrim',box(BW['Head']+np.array([0,.35,.45]),(.74,.07,.38)),'Head','gear')
    if role in {'pitcher','fielder','catcher'}:
        addpart('Glove',uv_sphere(BW['LWrist']+np.array([-.08,-.18,.12]),.34,seg,max(5,rings-2),scale=(1.15,.7,.6)),'LWrist','leather')
    if role=='batter':
        addpart('Bat',cylinder_between(BW['RWrist']+np.array([.1,-.2,.0]),BW['RWrist']+np.array([.45,2.7,.18]),.085,max(8,seg)),'RWrist','bat')
        if lod!='low':addpart('ElbowGuard',box(BW['LShoulder']+np.array([-.25,-.7,.28]),(.35,.62,.18)),'LShoulder','gear')
    if role=='catcher':
        addpart('ChestProtector',box((0,4.78,.53),(1.86,1.9,.25)),'Chest','gear')
        for side in ['L','R']:
            addpart(side+'ShinGuard',box(BW[side+'Knee']+np.array([0,-.6,.24]),(.48,1.28,.18)),side+'Knee','gear')
        if lod!='low':
            # mask bars as small cylinders bound to head
            hp=BW['Head']+np.array([0,.22,.4])
            for dx in [-.35,0,.35]:addpart('MaskBar',cylinder_between(hp+[-.0+dx,-.35,0],hp+[dx,.35,0],.035,6),'Head','metal')
            for dy in [-.28,0,.28]:addpart('MaskBarH',cylinder_between(hp+[-.42,dy,0],hp+[.42,dy,0],.035,6),'Head','metal')
    if role=='umpire':
        addpart('UmpChest',box((0,4.82,.52),(1.92,1.82,.27)),'Chest','gear')
        hp=BW['Head']+np.array([0,.2,.42])
        if lod!='low':
            for dx in [-.35,0,.35]:addpart('UmpMask',cylinder_between(hp+[dx,-.35,0],hp+[dx,.35,0],.035,6),'Head','metal')
            for dy in [-.28,0,.28]:addpart('UmpMaskH',cylinder_between(hp+[-.42,dy,0],hp+[.42,dy,0],.035,6),'Head','metal')
    if lod=='high':
        for side in ['L','R']:
            addpart(side+'Sock',cylinder_between(BW[side+'Knee']+np.array([0,-.65,0]),BW[side+'Ankle']+np.array([0,.12,0]),.265,12),side+'Knee','gear')
            addpart(side+'Wristband',cylinder_between(BW[side+'Wrist']+np.array([0,.10,0]),BW[side+'Wrist']+np.array([0,-.12,0]),.205,12),side+'Wrist','trim')
    mesh_index=len(g.j['meshes']);g.j['meshes'].append({'name':f'GT_{role}_{lod}_SkinnedMesh','primitives':primitives})
    mesh_node=g.add_node('GT_SkinnedCharacter',mesh=mesh_index,skin=0);g.j['nodes'][root].setdefault('children',[]).append(mesh_node)

    # animation helpers
    def rot_track(bone,times,eulers):return {'node':bone_nodes[bone],'path':'rotation','times':times,'values':[quat_xyz(*e) for e in eulers],'type':'VEC4'}
    def trans_track(bone,times,vals):return {'node':bone_nodes[bone],'path':'translation','times':times,'values':vals,'type':'VEC3'}
    # idle / crouch
    if role in {'catcher','umpire'}:
        times=[0,1,2];tracks=[trans_track('Hips',times,[(0,2.55,0),(0,2.58,0),(0,2.55,0)]),rot_track('Hips',times,[(.18,0,0),(.17,0,0),(.18,0,0)]),rot_track('LHip',times,[(.72,0,0),(.7,0,0),(.72,0,0)]),rot_track('RHip',times,[(.72,0,0),(.7,0,0),(.72,0,0)])]
    else:
        times=[0,1,2];tracks=[trans_track('Hips',times,[(0,3.15,0),(0,3.19,0),(0,3.15,0)]),rot_track('Chest',times,[(0,0,-.015),(0,0,.015),(0,0,-.015)])]
    g.add_animation('idle',tracks)
    # run
    t=[0,.25,.5,.75,1.0];g.add_animation('run',[rot_track('LHip',t,[(.7,0,0),(-.7,0,0),(.7,0,0),(-.7,0,0),(.7,0,0)]),rot_track('RHip',t,[(-.7,0,0),(.7,0,0),(-.7,0,0),(.7,0,0),(-.7,0,0)]),rot_track('LShoulder',t,[(-.55,0,0),(.55,0,0),(-.55,0,0),(.55,0,0),(-.55,0,0)]),rot_track('RShoulder',t,[(.55,0,0),(-.55,0,0),(.55,0,0),(-.55,0,0),(.55,0,0)])])
    # swing
    t=[0,.22,.5,.78,1.0];g.add_animation('swing',[rot_track('Hips',t,[(0,.2,0),(0,.35,0),(0,-1.05,0),(0,-1.4,0),(0,-.55,0)]),rot_track('Chest',t,[(0,.1,0),(0,.28,0),(0,-1.18,0),(0,-1.45,0),(0,-.55,0)]),rot_track('RShoulder',t,[(-.2,0,-.2),(-.5,.15,-.35),(-1.4,-.35,-.55),(-1.65,-.45,-.35),(-.55,-.1,-.2)]),rot_track('LShoulder',t,[(-.25,0,.2),(-.5,-.15,.35),(-1.2,.35,.55),(-1.4,.45,.35),(-.45,.1,.2)])])
    # pitch
    t=[0,.2,.42,.68,1.0];g.add_animation('pitch',[rot_track('Hips',t,[(0,0,0),(0,-.2,0),(0,-.45,0),(0,-.8,0),(.12,.22,0)]),rot_track('LHip',t,[(0,0,0),(-1.15,0,0),(-.8,0,0),(.2,0,0),(-.4,0,0)]),rot_track('RShoulder',t,[(-.2,0,-.1),(-.8,0,-.25),(-1.55,0,-.45),(-2.6,0,-.55),(-.8,0,-.15)]),rot_track('LShoulder',t,[(0,0,.15),(.35,0,.25),(.6,0,.3),(.1,0,.15),(-.1,0,.1)])])
    # field
    t=[0,.4,.8,1.0];g.add_animation('field',[rot_track('Hips',t,[(0,0,0),(.55,0,0),(.7,0,0),(.25,0,0)]),rot_track('LShoulder',t,[(0,0,.1),(-.7,0,.3),(-1.2,0,.4),(-.4,0,.15)]),rot_track('RShoulder',t,[(0,0,-.1),(-.7,0,-.3),(-1.2,0,-.4),(-.4,0,-.15)])])
    # throw
    t=[0,.3,.58,.82,1.0];g.add_animation('throw',[rot_track('Hips',t,[(0,0,0),(0,-.45,0),(0,-.65,0),(0,.25,0),(0,0,0)]),rot_track('RShoulder',t,[(-.2,0,-.1),(-1.4,0,-.45),(-2.5,0,-.55),(-.8,0,-.2),(-.2,0,-.1)]),rot_track('LShoulder',t,[(0,0,.1),(.35,0,.2),(.2,0,.15),(-.15,0,.05),(0,0,.1)])])
    # catch
    t=[0,.35,.7,1.0];g.add_animation('catch',[rot_track('LShoulder',t,[(0,0,.1),(-1.1,0,.35),(-1.35,0,.42),(-.25,0,.12)]),rot_track('RShoulder',t,[(0,0,-.1),(-.7,0,-.25),(-.9,0,-.3),(-.2,0,-.12)])])
    # tag
    t=[0,.45,.8,1.0];g.add_animation('tag',[rot_track('Hips',t,[(0,0,0),(.35,-.25,0),(.45,-.35,0),(.1,0,0)]),rot_track('LShoulder',t,[(0,0,.1),(-1.45,0,.45),(-1.65,0,.5),(-.3,0,.15)]),rot_track('RShoulder',t,[(0,0,-.1),(-1.0,0,-.25),(-1.2,0,-.3),(-.3,0,-.1)])])

    # v1.7 advanced baseball clips. These remain original generic motion, not player likeness motion capture.
    # handed batting stances
    t=[0,1,2]
    g.add_animation('stance_right',[rot_track('Hips',t,[(0,.18,0),(0,.21,0),(0,.18,0)]),rot_track('Chest',t,[(0,.16,0),(0,.19,0),(0,.16,0)]),rot_track('LShoulder',t,[(-.42,-.18,.28),(-.4,-.16,.3),(-.42,-.18,.28)]),rot_track('RShoulder',t,[(-.58,-.22,-.32),(-.56,-.2,-.34),(-.58,-.22,-.32)])])
    g.add_animation('stance_left',[rot_track('Hips',t,[(0,-.18,0),(0,-.21,0),(0,-.18,0)]),rot_track('Chest',t,[(0,-.16,0),(0,-.19,0),(0,-.16,0)]),rot_track('LShoulder',t,[(-.58,.22,.32),(-.56,.2,.34),(-.58,.22,.32)]),rot_track('RShoulder',t,[(-.42,.18,-.28),(-.4,.16,-.3),(-.42,.18,-.28)])])

    # multi-stage pitching mechanics
    g.add_animation('pitch_set',[rot_track('Hips',[0,.6,1],[(0,0,0),(0,-.08,0),(0,0,0)]),rot_track('RShoulder',[0,.6,1],[(-.18,0,-.1),(-.28,0,-.12),(-.18,0,-.1)])])
    g.add_animation('pitch_lift',[rot_track('Hips',[0,.45,1],[(0,0,0),(0,-.18,0),(0,-.28,0)]),rot_track('LHip',[0,.45,1],[(0,0,0),(-1.18,0,0),(-1.05,0,0)]),rot_track('RShoulder',[0,.45,1],[(-.2,0,-.1),(-.58,0,-.2),(-.9,0,-.3)])])
    g.add_animation('pitch_drive',[rot_track('Hips',[0,.35,.7,1],[(0,-.25,0),(0,-.45,0),(0,-.78,0),(.08,-.38,0)]),rot_track('LHip',[0,.35,.7,1],[(-1.0,0,0),(-.55,0,0),(.2,0,0),(-.2,0,0)]),rot_track('RShoulder',[0,.35,.7,1],[(-.8,0,-.3),(-1.5,0,-.46),(-2.7,0,-.58),(-1.25,0,-.25)]),rot_track('LShoulder',[0,.35,.7,1],[(.45,0,.25),(.62,0,.3),(.15,0,.14),(-.05,0,.08)])])
    g.add_animation('pitch_follow',[rot_track('Hips',[0,.45,1],[(.08,-.38,0),(.18,.18,0),(.06,0,0)]),rot_track('RShoulder',[0,.45,1],[(-1.25,0,-.25),(-.65,0,-.12),(-.2,0,-.1)]),rot_track('LHip',[0,.45,1],[(-.2,0,0),(-.48,0,0),(0,0,0)])])

    # split batting mechanics into load/contact/follow so the director can time contact precisely.
    g.add_animation('swing_load',[rot_track('Hips',[0,.5,1],[(0,.18,0),(0,.34,0),(0,.28,0)]),rot_track('Chest',[0,.5,1],[(0,.12,0),(0,.3,0),(0,.25,0)]),rot_track('RShoulder',[0,.5,1],[(-.3,0,-.2),(-.62,.12,-.38),(-.72,.16,-.4)]),rot_track('LShoulder',[0,.5,1],[(-.28,0,.2),(-.56,-.12,.38),(-.64,-.16,.4)])])
    g.add_animation('swing_contact',[rot_track('Hips',[0,.38,.72,1],[(0,.28,0),(0,-.52,0),(0,-1.18,0),(0,-1.35,0)]),rot_track('Chest',[0,.38,.72,1],[(0,.25,0),(0,-.6,0),(0,-1.25,0),(0,-1.42,0)]),rot_track('RShoulder',[0,.38,.72,1],[(-.72,.16,-.4),(-1.18,-.12,-.52),(-1.62,-.4,-.44),(-1.55,-.42,-.34)]),rot_track('LShoulder',[0,.38,.72,1],[(-.64,-.16,.4),(-1.08,.12,.52),(-1.45,.4,.44),(-1.4,.42,.34)])])
    g.add_animation('swing_follow',[rot_track('Hips',[0,.45,1],[(0,-1.35,0),(0,-.72,0),(0,-.34,0)]),rot_track('Chest',[0,.45,1],[(0,-1.42,0),(0,-.85,0),(0,-.38,0)]),rot_track('RShoulder',[0,.45,1],[(-1.55,-.42,-.34),(-1.0,-.2,-.28),(-.5,-.08,-.18)]),rot_track('LShoulder',[0,.45,1],[(-1.4,.42,.34),(-.95,.2,.28),(-.46,.08,.18)])])

    # catcher receive/pop and position-specific throws.
    g.add_animation('receive',[rot_track('Hips',[0,.4,.8,1],[(.18,0,0),(.24,0,0),(.18,0,0),(.16,0,0)]),rot_track('LShoulder',[0,.4,.8,1],[(-.55,0,.22),(-1.05,0,.35),(-1.22,0,.38),(-.68,0,.24)]),rot_track('RShoulder',[0,.4,.8,1],[(-.4,0,-.2),(-.62,0,-.24),(-.72,0,-.26),(-.45,0,-.2)])])
    g.add_animation('throw_infield',[rot_track('Hips',[0,.28,.55,.82,1],[(0,0,0),(0,-.35,0),(0,-.55,0),(0,.16,0),(0,0,0)]),rot_track('RShoulder',[0,.28,.55,.82,1],[(-.2,0,-.1),(-1.25,0,-.38),(-2.45,0,-.52),(-.72,0,-.18),(-.2,0,-.1)])])
    g.add_animation('throw_outfield',[rot_track('Hips',[0,.25,.5,.75,1],[(0,0,0),(.08,-.25,0),(0,-.62,0),(.15,.32,0),(0,0,0)]),rot_track('RShoulder',[0,.25,.5,.75,1],[(-.2,0,-.1),(-1.3,0,-.45),(-2.7,0,-.62),(-.8,0,-.18),(-.2,0,-.1)]),rot_track('LHip',[0,.25,.5,.75,1],[(0,0,0),(-.4,0,0),(.2,0,0),(-.18,0,0),(0,0,0)])])
    g.add_animation('throw_catcher',[rot_track('Hips',[0,.25,.5,.75,1],[(.18,0,0),(.08,-.18,0),(0,-.38,0),(.08,.12,0),(0,0,0)]),rot_track('RShoulder',[0,.25,.5,.75,1],[(-.45,0,-.18),(-1.2,0,-.34),(-2.35,0,-.48),(-.65,0,-.15),(-.25,0,-.1)]),rot_track('LHip',[0,.25,.5,.75,1],[(.65,0,0),(.25,0,0),(-.12,0,0),(.05,0,0),(0,0,0)]),rot_track('RHip',[0,.25,.5,.75,1],[(.65,0,0),(.25,0,0),(-.12,0,0),(.05,0,0),(0,0,0)])])

    # baserunning and reactions.
    g.add_animation('trot',[rot_track('LHip',[0,.25,.5,.75,1],[(.42,0,0),(-.42,0,0),(.42,0,0),(-.42,0,0),(.42,0,0)]),rot_track('RHip',[0,.25,.5,.75,1],[(-.42,0,0),(.42,0,0),(-.42,0,0),(.42,0,0),(-.42,0,0)]),rot_track('LShoulder',[0,.25,.5,.75,1],[(-.3,0,0),(.3,0,0),(-.3,0,0),(.3,0,0),(-.3,0,0)]),rot_track('RShoulder',[0,.25,.5,.75,1],[(.3,0,0),(-.3,0,0),(.3,0,0),(-.3,0,0),(.3,0,0)])])
    g.add_animation('slide',[trans_track('Hips',[0,.28,.62,1],[(0,3.15,0),(0,2.25,.15),(0,1.3,.52),(0,1.15,.82)]),rot_track('Hips',[0,.28,.62,1],[(0,0,0),(-.45,0,0),(-1.0,0,0),(-1.18,0,0)]),rot_track('LHip',[0,.28,.62,1],[(0,0,0),(.35,0,0),(.8,0,0),(.9,0,0)]),rot_track('RHip',[0,.28,.62,1],[(0,0,0),(.15,0,0),(.45,0,0),(.55,0,0)])])
    g.add_animation('celebrate',[rot_track('Chest',[0,.3,.65,1],[(0,0,0),(-.12,0,0),(.08,0,0),(0,0,0)]),rot_track('RShoulder',[0,.3,.65,1],[(-.2,0,-.1),(-2.1,0,-.25),(-1.65,0,-.12),(-.25,0,-.1)]),rot_track('LShoulder',[0,.3,.65,1],[(-.2,0,.1),(-1.5,0,.28),(-1.1,0,.18),(-.25,0,.1)])])
    g.add_animation('react_strikeout',[rot_track('Chest',[0,.4,.8,1],[(0,0,0),(.18,0,0),(.28,0,0),(.12,0,0)]),rot_track('Head',[0,.4,.8,1],[(0,0,0),(.12,-.18,0),(.18,-.28,0),(.08,-.1,0)]),rot_track('RShoulder',[0,.4,.8,1],[(-.2,0,-.1),(.15,0,-.2),(.28,0,-.25),(-.05,0,-.12)])])
    g.add_animation('react_out',[rot_track('Chest',[0,.45,.8,1],[(0,0,0),(.12,0,0),(.2,0,0),(.08,0,0)]),rot_track('Head',[0,.45,.8,1],[(0,0,0),(.08,.12,0),(.14,.18,0),(.06,.06,0)])])
    return g.write(out)


def unit_box():return box((0,0,0),(1,1,1))
def unit_cyl(seg=10):return cylinder_between((0,-.5,0),(0,.5,0),.5,seg)

def make_stadium(kind,lod,out):
    g=GLB();mat_con=g.add_material('GT_Stadium_Concrete',(.09,.13,.17,1),.84,.02);mat_seat=g.add_material('GT_Stadium_Seats',(.03,.10,.16,1),.72,.02);mat_metal=g.add_material('GT_Stadium_Metal',(.15,.22,.28,1),.35,.55);mat_board=g.add_material('GT_VideoBoard',(.01,.04,.06,1),.4,.1,emissive=(.02,.20,.36));mat_wall=g.add_material('GT_BatterEye',(.02,.16,.10,1),.78,.01)
    boxmesh=g.add_static_mesh('UnitBox',*unit_box(),mat_con);seatmesh=g.add_static_mesh('SeatBlock',*unit_box(),mat_seat);metalmesh=g.add_static_mesh('MetalBox',*unit_box(),mat_metal);boardmesh=g.add_static_mesh('VideoBoard',*unit_box(),mat_board);wallmesh=g.add_static_mesh('BatterEye',*unit_box(),mat_wall);cylmesh=g.add_static_mesh('Pole',*unit_cyl(8 if lod=='low' else 12),mat_metal)
    root=g.add_node('StadiumRoot');g.j['scenes'][0]['nodes'].append(root)
    def node(name,mesh,pos,scale,rot=None):
        kw={'mesh':mesh,'translation':list(map(float,pos)),'scale':list(map(float,scale))}
        if rot:kw['rotation']=quat_xyz(*rot).astype(float).tolist()
        ni=g.add_node(name,**kw);g.j['nodes'][root].setdefault('children',[]).append(ni);return ni
    if kind=='generic_stadium':
        n={'low':18,'medium':34,'high':58}[lod]
        # center-field seating bowl arc
        for i in range(n):
            a=math.radians(-68+136*i/max(1,n-1));r=330+(i%3)*18;x=math.sin(a)*r;z=-math.cos(a)*r;y=18+(i%3)*16
            node(f'Stand_{i}',seatmesh,(x,y,z),(18,14+(i%3)*4,9),(0,a,0))
        # upper deck / concourse ribbons
        if lod!='low':
            for i in range(max(10,n//2)):
                a=math.radians(-65+130*i/max(1,max(10,n//2)-1));r=382;x=math.sin(a)*r;z=-math.cos(a)*r
                node(f'Upper_{i}',seatmesh,(x,64,z),(20,12,8),(0,a,0))
        node('CenterScoreboard',boardmesh,(0,72,-350),(50,28,3))
        node('BatterEye',wallmesh,(0,22,-330),(38,22,3))
        # light towers
        tower_count=4 if lod=='low' else 6
        for i,x in enumerate(np.linspace(-250,250,tower_count)):
            node(f'LightPole_{i}',cylmesh,(float(x),65,-300),(2,130,2))
            node(f'LightBank_{i}',metalmesh,(float(x),132,-300),(18,4,5))
        # roof canopies high
        if lod=='high':
            for side in [-1,1]:
                for i in range(5):node(f'Roof_{side}_{i}',metalmesh,(side*(145+i*35),98,-315+i*8),(34,2,26),(0,side*.18,side*.05))
    else:
        # modular baseball support structures near foul lines
        for side in [-1,1]:
            node(f'Dugout_{side}',boxmesh,(side*95,6,-24),(38,11,12))
            node(f'DugoutRoof_{side}',metalmesh,(side*95,13,-24),(42,2,15))
            node(f'Bullpen_{side}',seatmesh,(side*178,5,-125),(34,9,10))
            node(f'CameraWell_{side}',boxmesh,(side*42,3,8),(14,6,8))
        node('Backstop',metalmesh,(0,10,22),(56,20,1))
        if lod!='low':
            node('RibbonBoard',boardmesh,(0,50,-310),(120,5,2))
            for side in [-1,1]:node(f'FoulPole_{side}',cylmesh,(side*225,48,-235),(1,96,1))
        if lod=='high':
            for side in [-1,1]:node(f'BullpenCanopy_{side}',metalmesh,(side*178,14,-125),(40,2,18))
    return g.write(out)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');args=ap.parse_args()
    roles=['generic_player','batter','pitcher','fielder','runner','catcher','umpire'];qualities=['low','medium','high'];hashes={}
    for role in roles:
        rr='fielder' if role=='generic_player' else role
        for q in qualities:
            p=OUT/'characters'/f'{role}-{q}.glb';hashes[str(p.relative_to(ROOT))]=make_character(rr,q,p)
    for kind in ['generic_stadium','stadium_modules']:
        for q in qualities:
            p=OUT/'stadium'/f'{kind}-{q}.glb';hashes[str(p.relative_to(ROOT))]=make_stadium(kind,q,p)
    (OUT/'ASSET_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(f'generated {len(hashes)} original GameTwin GLB assets in {OUT}')

if __name__=='__main__':main()
