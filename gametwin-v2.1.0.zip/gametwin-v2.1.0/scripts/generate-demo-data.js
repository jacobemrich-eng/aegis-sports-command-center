'use strict';
const fs=require('fs');
const path=require('path');
const {buildBroadcast}=require('../src/gametwin-broadcast');
const {buildGameViewModel}=require('../src/gametwin-viewmodel');

const lineup=(prefix,positions)=>positions.map((position,i)=>({
  id:1000+i,name:`${prefix} ${i+1}`,position,bats:['R','L','S'][i%3],
  statcast:{avg_exit_velocity:88.5+(i%4)*1.4,avg_launch_angle:10+(i%5)*2}
}));
const awayLineup=lineup('ATL Demo',['CF','2B','RF','1B','DH','LF','3B','SS','C']);
const homeLineup=lineup('NY Demo',['SS','LF','1B','RF','DH','3B','CF','C','2B']);
const game={
  gamePk:990001,status:'READY',date:'DEMO',away:'Atlanta Demo',home:'New York Demo',venue:'Citi Field — Demo',simulations:25000,
  weather:{temperature_f:74,wind_mph:8,wind_direction_deg:65,precipitation_probability:8,weather_code:1,verified:false,demo:true},
  projected_score:{away:4.6,home:4.1,total:8.7},win_probability:{away:.548,home:.452},fair_moneyline:{away:-121,home:121},
  markets:{away_minus_1_5:.342,home_minus_1_5:.287,over_8_5:.518,under_8_5:.482},
  model_comparison:{available:true,source:'illustrative_demo_only',book:'Demo Market',away:{selection:'Atlanta Demo',gametwin:.548,aegis:.531,market:.518,price:-108,book:'Demo Market'},home:{selection:'New York Demo',gametwin:.452,aegis:.469,market:.482,price:-102,book:'Demo Market'}},
  top_hr:{away:[{name:'ATL Demo 4',HR_probability:.238},{name:'ATL Demo 3',HR_probability:.192},{name:'ATL Demo 5',HR_probability:.168}],home:[{name:'NY Demo 3',HR_probability:.211},{name:'NY Demo 4',HR_probability:.183},{name:'NY Demo 5',HR_probability:.154}]},
  pitcher_projections:{away:{name:'Atlanta Demo SP',K:6.1,outs:17.2,ER:2.7,pitch_count:92},home:{name:'New York Demo SP',K:5.7,outs:16.8,ER:3.0,pitch_count:94}},
  data_quality:{lineups:'demo-confirmed',starters:'demo-confirmed',weather:'demo',shadow_only:true},
  integration:{mode:'shadow-demo',aegis_weight:0,release_eligible:false},
  broadcast_context:{
    gamePk:990001,date:'2026-09-04T23:10:00Z',
    venue:{id:3289,name:'Citi Field — Demo',field:{left_line:335,left_center:385,center:408,right_center:375,right_line:330,roof:'Open'},timezone:'America/New_York',coordinates:{latitude:40.7571,longitude:-73.8458}},
    weather:{temperature_f:74,wind_mph:8,wind_direction_deg:65,precipitation_probability:8,weather_code:1,verified:false,demo:true},
    away:{name:'Atlanta Demo',lineup:awayLineup,starter:{name:'Atlanta Demo SP',throws:'R',arsenal:[{pitch_type:'FF',usage:.46},{pitch_type:'SL',usage:.27},{pitch_type:'CH',usage:.17},{pitch_type:'CU',usage:.10}]},bullpen:[{name:'Atlanta Demo RP',role:'setup',throws:'R',arsenal:[{pitch_type:'FF',usage:.58},{pitch_type:'SL',usage:.42}]}]},
    home:{name:'New York Demo',lineup:homeLineup,starter:{name:'New York Demo SP',throws:'L',arsenal:[{pitch_type:'SI',usage:.38},{pitch_type:'SL',usage:.31},{pitch_type:'CH',usage:.19},{pitch_type:'FC',usage:.12}]},bullpen:[{name:'New York Demo RP',role:'closer',throws:'R',arsenal:[{pitch_type:'FF',usage:.62},{pitch_type:'SL',usage:.38}]}]},
    presentation_only:true,demo:true
  },
  representative_game:{final:{away:5,home:4},play_by_play:[
    {inning:1,half:'top',pa_number:1,batter:'ATL Demo 1',pitcher:'New York Demo SP',outcome:'BB',pitch_count:5,outs_before:0,outs_after:0,scored:[],bases:['ATL Demo 1',null,null]},
    {type:'steal',inning:1,half:'top',runner:'ATL Demo 1',from_base:1,to_base:2,success:true,outs_before:0},
    {inning:1,half:'top',pa_number:2,batter:'ATL Demo 2',pitcher:'New York Demo SP',outcome:'OUT',pitch_count:3,outs_before:0,outs_after:1,scored:[],bases:[null,'ATL Demo 1',null]},
    {inning:1,half:'top',pa_number:3,batter:'ATL Demo 3',pitcher:'New York Demo SP',outcome:'2B',pitch_count:4,outs_before:1,outs_after:1,scored:['ATL Demo 1'],bases:[null,'ATL Demo 3',null]},
    {inning:1,half:'top',pa_number:4,batter:'ATL Demo 4',pitcher:'New York Demo SP',outcome:'HR',pitch_count:6,outs_before:1,outs_after:1,scored:['ATL Demo 3','ATL Demo 4'],bases:[null,null,null]},
    {inning:1,half:'top',pa_number:5,batter:'ATL Demo 5',pitcher:'New York Demo SP',outcome:'K',pitch_count:4,outs_before:1,outs_after:2,scored:[],bases:[null,null,null]},
    {inning:1,half:'top',pa_number:6,batter:'ATL Demo 6',pitcher:'New York Demo SP',outcome:'OUT',pitch_count:2,outs_before:2,outs_after:3,scored:[],bases:[null,null,null]},
    {inning:1,half:'bottom',pa_number:1,batter:'NY Demo 1',pitcher:'Atlanta Demo SP',outcome:'1B',pitch_count:2,outs_before:0,outs_after:0,scored:[],bases:['NY Demo 1',null,null]},
    {inning:1,half:'bottom',pa_number:2,batter:'NY Demo 2',pitcher:'Atlanta Demo SP',outcome:'K',pitch_count:5,outs_before:0,outs_after:1,scored:[],bases:['NY Demo 1',null,null]},
    {inning:1,half:'bottom',pa_number:3,batter:'NY Demo 3',pitcher:'Atlanta Demo SP',outcome:'HR',pitch_count:3,outs_before:1,outs_after:1,scored:['NY Demo 1','NY Demo 3'],bases:[null,null,null]},
    {inning:1,half:'bottom',pa_number:4,batter:'NY Demo 4',pitcher:'Atlanta Demo SP',outcome:'K',pitch_count:6,outs_before:1,outs_after:2,scored:[],bases:[null,null,null]},
    {inning:1,half:'bottom',pa_number:5,batter:'NY Demo 5',pitcher:'Atlanta Demo SP',outcome:'OUT',pitch_count:4,outs_before:2,outs_after:3,scored:[],bases:[null,null,null]},
    {inning:7,half:'top',pa_number:1,batter:'ATL Demo 7',pitcher:'New York Demo RP',outcome:'2B',pitch_count:4,outs_before:0,outs_after:0,scored:[],bases:[null,'ATL Demo 7',null]},
    {inning:7,half:'top',pa_number:2,batter:'ATL Demo 8',pitcher:'New York Demo RP',outcome:'1B',pitch_count:5,outs_before:0,outs_after:0,scored:['ATL Demo 7'],bases:['ATL Demo 8',null,null]},
    {inning:8,half:'bottom',pa_number:1,batter:'NY Demo 6',pitcher:'Atlanta Demo RP',outcome:'2B',pitch_count:3,outs_before:0,outs_after:0,scored:[],bases:[null,'NY Demo 6',null]},
    {inning:8,half:'bottom',pa_number:2,batter:'NY Demo 7',pitcher:'Atlanta Demo RP',outcome:'1B',pitch_count:4,outs_before:0,outs_after:0,scored:['NY Demo 6'],bases:['NY Demo 7',null,null]},
    {inning:9,half:'top',pa_number:1,batter:'ATL Demo 9',pitcher:'New York Demo RP',outcome:'HR',pitch_count:5,outs_before:0,outs_after:0,scored:['ATL Demo 9'],bases:[null,null,null]},
    {inning:9,half:'bottom',pa_number:1,batter:'NY Demo 8',pitcher:'Atlanta Demo RP',outcome:'HR',pitch_count:4,outs_before:0,outs_after:0,scored:['NY Demo 8'],bases:[null,null,null]},
    {inning:9,half:'bottom',pa_number:2,batter:'NY Demo 9',pitcher:'Atlanta Demo RP',outcome:'OUT',pitch_count:3,outs_before:0,outs_after:1,scored:[],bases:[null,null,null]},
    {inning:9,half:'bottom',pa_number:3,batter:'NY Demo 1',pitcher:'Atlanta Demo RP',outcome:'K',pitch_count:5,outs_before:1,outs_after:2,scored:[],bases:[null,null,null]},
    {inning:9,half:'bottom',pa_number:4,batter:'NY Demo 2',pitcher:'Atlanta Demo RP',outcome:'OUT',pitch_count:4,outs_before:2,outs_after:3,scored:[],bases:[null,null,null]}
  ]}
};
const broadcast=buildBroadcast(game);
const viewModel=buildGameViewModel(game,broadcast,[]);
const status={version:'2.1.0-mobile-demo',mode:'shadow-demo',operational_health:'GREEN',demo:true,pilot:{enabled:true,health:'GREEN',circuit:'CLOSED, DEMO',consecutive_failures:0,last_success_at:'DEMO'},runtime:{state:'IDLE'},integration:{aegis_weight:0,release_eligible:false}};
const slate={date:'DEMO',saved_at:'DEMO',summary:{total:1,ready:1,provisional:0,errors:0},games:[game],integration:{mode:'shadow-demo',aegis_weight:0,release_eligible:false},demo:true};
const calibration={final_games:0,forecasts:0,overall:{brier:null},families:[],comparisons:{vs_aegis:{n:0},vs_closing_market:{n:0}},governance:{status:'DEMO / NOT SCORED',current_final_games:0,minimum_final_games:50,current_binary_forecasts:0,minimum_binary_forecasts:200,note:'This preview uses illustrative demo data only. It is not a real projection and does not count toward calibration.'},demo:true};
const payload={status,slate,calibration,games:{[game.gamePk]:{game,broadcast,view_model:viewModel,integration:{mode:'shadow-demo',aegis_weight:0,release_eligible:false},demo:true}}};
const out=`'use strict';\nwindow.GameTwinDemo=${JSON.stringify(payload)};\n`;
fs.writeFileSync(path.join(__dirname,'..','public','gametwin-demo-data.js'),out);
console.log('wrote public/gametwin-demo-data.js');
