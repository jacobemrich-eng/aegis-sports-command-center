# GameTwin v2.1 Deployment Readiness Contract

## Package gate
- Full GameTwin test/syntax gate must pass.
- All bundled GLBs must pass asset verification.
- `scripts/verify-deployment-readiness.js` must return `ok=true`.
- The exact release ZIP must be checksum-verified after clean extraction.

## AEGIS preflight gate
Run:

`node scripts/install-into-aegis-v8.9.3.js --preflight /path/to/aegis-sports-command-center`

Required:
- AEGIS package version `8.9.3`.
- `server.js` and `public/index.html` integration anchors present or existing GameTwin hooks recognized.
- `write_performed=false`.
- `aegis_weight=0`.
- `release_eligible=false`.

## Runtime observability
The WebGL renderer emits advisory `gametwin:performance-sample`, `gametwin:webgl-context`, and `gametwin:asset-status` events. These are presentation-health signals only.

## Merge blockers
Do not merge if:
- shadow firewall changes;
- installer preflight fails;
- renderer repeatedly reports RED on the target phone at Low quality;
- local GLB loads fail without procedural fallback;
- overlay collisions obscure score/outs/count on supported portrait/landscape profiles;
- any pre-existing AEGIS production feature regresses.
