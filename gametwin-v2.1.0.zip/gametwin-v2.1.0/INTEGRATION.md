# GameTwin v2.1.0 Integration

v2.1 adds `public/gametwin-readiness.mjs`, collision-safe production CSS/UI behavior, renderer performance/WebGL telemetry, deployment verification, and installer preflight. The guarded installer still targets AEGIS Command Center **v8.9.3** and copies only GameTwin-prefixed source/tests/public files plus `public/gametwin-assets/`.

## Safe deployment sequence
1. Create a feature branch from the verified AEGIS main commit.
2. Run package-local `npm run check`.
3. Run `node scripts/install-into-aegis-v8.9.3.js --preflight /path/to/aegis`.
4. Confirm `compatible=true`, `write_performed=false`, `aegis_weight=0`, and `release_eligible=false`.
5. Only then run the installer without `--preflight`.
6. Run the host repository's existing checks plus GameTwin tests.
7. Smoke-test `/gametwin.html` on mobile portrait and landscape before merge.
8. Merge/deploy only after AEGIS Final Card, Game Lab, Results, Models, Supabase persistence, Render, and autopilot are verified unchanged.

## Layering
1. GameTwin simulation owns events/projections.
2. v1.8 choreography depicts the frozen event.
3. v1.9 director sequences cameras/replays.
4. v2.0 Broadcast Experience emits TV graphics.
5. v2.1 Readiness layer manages layout/performance/asset telemetry and deployment checks.

Layer 5 has `predictive_authority=false` and cannot modify outcomes or betting authority.
